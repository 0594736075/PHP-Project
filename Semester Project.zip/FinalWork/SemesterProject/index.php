<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Study Planner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 800px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }
        
        .header {
            background: #4A6FCB;
            color: white;
            padding: 25px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .header p {
            opacity: 0.9;
        }
        
        .planner-container {
            padding: 30px;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .input-group input, 
        .input-group textarea, 
        .input-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .input-group input:focus, 
        .input-group textarea:focus, 
        .input-group select:focus {
            border-color: #4A6FCB;
            outline: none;
        }
        
        .input-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        button {
            background: #4A6FCB;
            color: white;
            border: none;
            padding: 14px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            transition: background 0.3s;
        }
        
        button:hover {
            background: #3B5AA6;
        }
        
        .divider {
            height: 1px;
            background: #eee;
            margin: 30px 0;
        }
        
        .tasks-container {
            margin-top: 30px;
        }
        
        .tasks-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .tasks-header h2 {
            color: #333;
        }
        
        .filter-options {
            display: flex;
            gap: 10px;
        }
        
        .filter-options select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
        }
        
        .task-list {
            display: grid;
            gap: 15px;
        }
        
        .task-item {
            background: #f9f9f9;
            border-left: 5px solid #4A6FCB;
            border-radius: 8px;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: transform 0.2s;
        }
        
        .task-item:hover {
            transform: translateY(-3px);
        }
        
        .task-info h3 {
            color: #333;
            margin-bottom: 8px;
        }
        
        .task-info p {
            color: #666;
            margin-bottom: 5px;
        }
        
        .due-date {
            background: #FFEAA7;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 14px;
            display: inline-block;
            margin-top: 5px;
        }
        
        .task-actions {
            display: flex;
            gap: 10px;
        }
        
        .task-actions button {
            width: auto;
            padding: 8px 12px;
            font-size: 14px;
        }
        
        .delete-btn {
            background: #ff4757;
        }
        
        .delete-btn:hover {
            background: #ff2e43;
        }
        
        .completed {
            border-left-color: #2ecc71;
            opacity: 0.8;
        }
        
        .completed .task-info h3 {
            text-decoration: line-through;
            color: #888;
        }
        
        .no-tasks {
            text-align: center;
            padding: 30px;
            color: #888;
        }
        
        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .alert.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 600px) {
            .task-item {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .task-actions {
                margin-top: 15px;
                align-self: flex-end;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Student Study Planner</h1>
            <p>Plan your studies effectively and achieve your academic goals</p>
        </div>
        
        <div class="planner-container">
            <?php
            // Enable error reporting
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
            
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "studentplanner";
            
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            
            // Check connection
            if ($conn->connect_error) {
                die("<div class='alert error'>Connection failed: " . $conn->connect_error . "</div>");
            }
            
            // Initialize variables
            $success_message = "";
            $error_message = "";
            
            // Process form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $subject = $_POST['subject'];
                $task = $_POST['task'];
                $due_date = $_POST['due_date'];
                
                // Insert into database
                $sql = "INSERT INTO study_tasks (subject, task_description, due_date) 
                        VALUES ('$subject', '$task', '$due_date')";
                
                if ($conn->query($sql) === TRUE) {
                    $success_message = "Task added successfully!";
                } else {
                    $error_message = "Error: " . $sql . "<br>" . $conn->error;
                }
            }
            
            // Fetch tasks from database
            $tasks = [];
            $sql = "SELECT * FROM study_tasks ORDER BY due_date ASC";
            $result = $conn->query($sql);
            
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $tasks[] = $row;
                }
            }
            ?>
            
            <!-- Display success/error messages -->
            <?php if (!empty($success_message)): ?>
                <div class="alert success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if (!empty($error_message)): ?>
                <div class="alert error"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <!-- Input Form -->
            <form method="POST" action="">
                <div class="input-group">
                    <label for="subject">Subject</label>
                    <select id="subject" name="subject" required>
                        <option value="">Select a subject</option>
                        <option value="Mathematics">Mathematics</option>
                        <option value="Science">Science</option>
                        <option value="English">English</option>
                        <option value="History">History</option>
                        <option value="Computer Science">Computer Science</option>
                        <option value="Physics">Physics</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Biology">Biology</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                
                <div class="input-group">
                    <label for="task">Task</label>
                    <textarea id="task" name="task" placeholder="Describe the study task..." required></textarea>
                </div>
                
                <div class="input-group">
                    <label for="due_date">Due Date</label>
                    <input type="date" id="due_date" name="due_date" required>
                </div>
                
                <button type="submit" name="add_task">Add To Planner</button>
            </form>
            
            <div class="divider"></div>
            
            <div class="tasks-container">
                <div class="tasks-header">
                    <h2>Your Study Tasks</h2>
                    <div class="filter-options">
                        <select id="filterSubject">
                            <option value="all">All Subjects</option>
                            <option value="Mathematics">Mathematics</option>
                            <option value="Science">Science</option>
                            <option value="English">English</option>
                            <option value="History">History</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Physics">Physics</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Biology">Biology</option>
                            <option value="Other">Other</option>
                        </select>
                        <select id="filterStatus">
                            <option value="all">All Tasks</option>
                            <option value="pending">Pending</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                </div>
                
                <div id="taskList" class="task-list">
                    <?php if (empty($tasks)): ?>
                        <div class="no-tasks">
                            <i class="fas fa-tasks" style="font-size: 48px; margin-bottom: 15px;"></i>
                            <h3>No tasks found</h3>
                            <p>Try adding a new task</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($tasks as $task): ?>
                            <div class="task-item">
                                <div class="task-info">
                                    <h3><?php echo htmlspecialchars($task['subject']); ?></h3>
                                    <p><?php echo htmlspecialchars($task['task_description']); ?></p>
                                    <span class="due-date">Due: <?php echo date('M j, Y', strtotime($task['due_date'])); ?></span>
                                </div>
                                <div class="task-actions">
                                    <button class="toggle-btn">Mark Done</button>
                                    <button class="delete-btn">Delete</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Set today's date as default for the due date field
        const today = new Date();
        const yyyy = today.getFullYear();
        let mm = today.getMonth() + 1;
        let dd = today.getDate();
        
        if (dd < 10) dd = '0' + dd;
        if (mm < 10) mm = '0' + mm;
        
        const formattedToday = ${yyyy}-${mm}-${dd};
        document.getElementById('due_date').value = formattedToday;
        document.getElementById('due_date').min = formattedToday;
        
        // Simple client-side filtering
        document.getElementById('filterSubject').addEventListener('change', function() {
            const filterValue = this.value.toLowerCase();
            const tasks = document.querySelectorAll('.task-item');
            
            tasks.forEach(task => {
                const subject = task.querySelector('h3').textContent.toLowerCase();
                if (filterValue === 'all' || subject === filterValue) {
                    task.style.display = 'flex';
                } else {
                    task.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>